<?php 
include('UserInformation.php');
 echo UserInfo::get_ip();
 ?>