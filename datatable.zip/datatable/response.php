<?php

$conn=mysqli_connect("localhost","root","","phpsamples");

$params = $columns = $totalRecords = $data = array();

	$params = $_REQUEST;

	
	$columns = array( 
		0 =>'id',
		1 =>'name', 
		2 => 'email'
		
	);

	$where = $sqlTot = $sqlRec = "";

	
	if( !empty($params['search']['value']) ) {   
		$where .=" WHERE ";
		$where .=" ( id LIKE '".$params['search']['value']."%' ";    
		$where .=" OR name LIKE '".$params['search']['value']."%' ";

		$where .=" OR email LIKE '".$params['search']['value']."%' )";
	}



	
	$sql = "SELECT * FROM `users` ";
	$sqlTot .= $sql;
	$sqlRec .= $sql;
	
	if(isset($where) && $where != '') {

		$sqlTot .= $where;
		$sqlRec .= $where;
	}


 	$sqlRec .=  " ORDER BY ". $columns[$params['order'][0]['column']]."   ".$params['order'][0]['dir']."  LIMIT ".$params['start']." ,".$params['length']." ";

	$queryTot = mysqli_query($conn, $sqlTot) or die("database error:". mysqli_error($conn));


	$totalRecords = mysqli_num_rows($queryTot);

	$queryRecords = mysqli_query($conn, $sqlRec) or die("error to fetch employees data");

	
	while( $row = mysqli_fetch_row($queryRecords) ) { 
		$data[] = $row;
	}	

	$json_data = array(
			"draw"            => intval( $params['draw'] ),   
			"recordsTotal"    => intval( $totalRecords ),  
			"recordsFiltered" => intval($totalRecords),
			"data"            => $data   
			);

	echo json_encode($json_data);  
?>